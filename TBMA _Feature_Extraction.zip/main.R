library(data.table)
library(ranger)
library(RcppRoll)
library(lubridate)
library(readr)
library(plyr)
library(forecast)
library(weathermetrics)
library(forecast)
library(caret)
library(zoo)

free <- function() invisible(gc())
  
    number_of_replication<-1
    prediction_date<-as.Date("2018-01-01")                 #first date to predict                      
    num_of_days_to_predict<-372                          #how many days we want to predict
    directory_of_raw_data<-"/home/mehmet-fazil.aydinli/data.csv"
    source_date_based_info<-"/home/mehmet-fazil.aydinli/date_based_information.R"
    source_weather<-"/home/mehmet-fazil.aydinli/weather.R"
    directory_weather_file<-"/home/mehmet-fazil.aydinli/WeatherData/"       #only the file
    source_functions<-"/home/mehmet-fazil.aydinli/functions.R"
    num_of_days_in_adv<-7
    set.seed(1)
    
    
    source(source_functions)
    #data preparation
    processed_data<-data_preperation(directory_of_raw_data,source_date_based_info,source_weather,directory_weather_file)
    rm(list=setdiff(ls(), c("processed_data","prediction_date","num_of_days_in_adv","num_of_days_to_predict","number_of_replication",
                            "best_models","add_models","xgb_model","xgb_tuner","forecast_rfma_without_arima","ozel_gun_adları","ozel_gunler","free","tbma_feature","feature_filter","best_ranger")))
    
    free()
    
    #feature selection
    selected_columns<-feature_filter(processed_data = processed_data)
    processed_data<-processed_data[,colnames(processed_data) %in% c(selected_columns,"Consumption","Date","Hour"), with=FALSE]
   
    #cv for models
    #final_model<-best_ranger(processed_data =processed_data,prediction_date,num_of_days_in_adv = num_of_days_in_adv,method="timeslice",today=prediction_date-num_of_days_in_adv)
    #final_models<-best_models(processed_data =processed_data,prediction_date,num_of_days_in_adv = num_of_days_in_adv,method="timeslice",today=prediction_date-num_of_days_in_adv)
    data<-tbma_feature(processed_data=processed_data,today=prediction_date-num_of_days_in_adv,num_of_days_in_adv=num_of_days_in_adv)

    xgb_parameter_only_tbma<-xgb_tuner(processed_data =data,prediction_date,num_of_days_in_adv = num_of_days_in_adv,method="timeslice",today=prediction_date-num_of_days_in_adv)
    data<-merge(data,y= processed_data , by = c("Date","Hour","Consumption"), all.x=TRUE)
    xgb_parameter_full<-xgb_tuner(processed_data =data,prediction_date,num_of_days_in_adv = num_of_days_in_adv,method="timeslice",today=prediction_date-num_of_days_in_adv)
    
    
    forecast_xgb_only_tbma<-data.table()
    forecast_xgb_full<-data.table()
    for(z in 1:num_of_days_to_predict){
    
      tm=Sys.time()  
            tm=Sys.time()
            set.seed(1)
            #tbma<-forecast_rfma_without_arima(processed_data = processed_data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv = num_of_days_in_adv,
            #                                  mtry =final_model$mtry,min_node_size = final_model$min_node_size,splitrule =final_model$splitrule)
            #other_models<-add_models(processed_data=processed_data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv=num_of_days_in_adv,
            #                         interaction.depth=final_models$interaction.depth,n.trees=final_models$n.trees,shrinkage=final_models$shrinkage,
            #                         n.minobsinnode=final_models$n.minobsinnode,alpha=final_models$alpha,lambda=final_models$lambda,
            #                         cp=final_models$cp,k=final_models$k,nrounds=final_models$nrounds, max_depth=final_models$max_depth, eta=final_models$eta,
            #                         gamma=final_models$gamma, colsample_bytree=final_models$colsample_bytree, min_child_weight=final_models$min_child_weight,
            #                         subsample=final_models$subsample)
            #combined<-result<-merge(tbma, other_models, by = c("Date","Hour"), all.x=TRUE)
            #forecast<-rbind(forecast,data.table(Today=prediction_date-num_of_days_in_adv+z-1,combined))
            data<-tbma_feature(processed_data=processed_data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv=num_of_days_in_adv)
            #data=data[complete.cases(data)]
            forecast_xgb_only_tbma<-rbind(forecast_xgb_only_tbma,xgb_model(processed_data=data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv=num_of_days_in_adv,
                                                                        nrounds=xgb_parameter_only_tbma$nrounds, max_depth=xgb_parameter_only_tbma$max_depth, eta=xgb_parameter_only_tbma$eta,
                                                                        gamma=xgb_parameter_only_tbma$gamma, colsample_bytree=xgb_parameter_only_tbma$colsample_bytree, min_child_weight=xgb_parameter_only_tbma$min_child_weight,
                                                                        subsample=xgb_parameter_only_tbma$subsample))
            data<-merge(data,y= processed_data , by = c("Date","Hour","Consumption"), all.x=TRUE)
            forecast_xgb_full<-rbind(forecast_xgb_full,xgb_model(processed_data=data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv=num_of_days_in_adv,
                                               nrounds=xgb_parameter_full$nrounds, max_depth=xgb_parameter_full$max_depth, eta=xgb_parameter_full$eta,
                                               gamma=xgb_parameter_full$gamma, colsample_bytree=xgb_parameter_full$colsample_bytree, min_child_weight=xgb_parameter_full$min_child_weight,
                                               subsample=xgb_parameter_full$subsample))
            
            cat("\n", z,"\n compute time:",(Sys.time()-tm),"   prediction date:",as.Date(prediction_date+z-1),"  num_of_days_in_adv:",num_of_days_in_adv ,"\n")
      free()  
    
    }
    
    

    write.csv(forecast_xgb_only_tbma,file="xgb_partial.csv")
    write.csv(forecast_xgb_full,file="xgb_full.csv")
    write.csv(selected_columns,file="selected_columns.csv")
    write.csv(xgb_parameter_only_tbma,file="xgb_parameter_only_tbma.csv")
    write.csv(xgb_parameter_full,file="xgb_parameter_full.csv")
    
    