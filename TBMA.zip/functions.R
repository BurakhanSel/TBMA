library(data.table)
library(ranger)
library(RcppRoll)
library(lubridate)
library(readr)
library(plyr)
library(forecast)
library(weathermetrics)
library(forecast)
library(caret)
library(zoo)
library(MLmetrics)
library(gbm)
library(MASS)
library(fastDummies)
library(e1071)
library(glmnet)

data_preperation<-function(directory_of_raw_data,source_date_based_info,source_weather,directory_weather_file){
  
  
  raw_data=as.data.table(read.csv(directory_of_raw_data)) #read data                                   
  
  raw_data[,Date:=as.Date(Date,format="%d.%m.%Y")]
  raw_data[,Hour:=as.character(hour(as.POSIXct(raw_data$Hour, format="%H:%M")))]
  raw_data[,Month:=as.character(month(as.POSIXct(raw_data$Date, format="%d.%m.%Y")))]
  raw_data[,Day_of_Month:=as.character(day(as.POSIXct(raw_data$Date, format="%d.%m.%Y")))]
  raw_data[,Consumption..MWh.:=as.numeric(gsub(",","",Consumption..MWh.))]
  colnames(raw_data)[colnames(raw_data)=="Consumption..MWh."] <- "Consumption"
  
  raw_data[,TWeekDay:=as.character(wday(Date))]

  #Date based information
  source(source_date_based_info)       
  
  
  #Adding Special Dates From Environment----
  for(i in 1:length(ozel_gun_adları)){
    list1<-as.data.table(ozel_gunler[i])
    raw_data<-raw_data[Date %in% list1$V1 , ozel_gun_adları[i]:=TRUE] 
    raw_data<-raw_data[!(Date %in% list1$V1) , ozel_gun_adları[i]:=FALSE]
    raw_data<-raw_data[(Date-1) %in% list1$V1 , ozel_gun_adları_lag1[i]:=TRUE] 
    raw_data<-raw_data[!((Date-1) %in% list1$V1) , ozel_gun_adları_lag1[i]:=FALSE]
    raw_data<-raw_data[(Date-7) %in% list1$V1 , ozel_gun_adları_lag7[i]:=TRUE] 
    raw_data<-raw_data[!((Date-7) %in% list1$V1) , ozel_gun_adları_lag7[i]:=FALSE]
  } 
  
  source(source_weather)
  wide_result<-weather_function(directory =directory_weather_file )
  
  raw_data<-join(raw_data,wide_result,by=c("Date","Hour"))
  

  
  for(k in names(wide_result)[-c(1:2)]){
    commnd=sprintf('raw_data[,%s:=as.numeric(na.interp(ts(%s)))]',k,k)
    eval(parse(text=commnd))
  }

  raw_data$day_number<- seq.int(nrow(raw_data))
  
  cols <-  colnames(raw_data)[sapply(raw_data, class) == 'logical']
  raw_data[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]

  
  raw_data[,Day_of_Month:=as.numeric(as.character(Day_of_Month))]
  raw_data[,Hour:=as.numeric(as.character(Hour))]
  raw_data[,xhr:= sin(2*pi*Hour/24)]
  raw_data[,yhr:= cos(2*pi*Hour/24)]
  raw_data[,Hour:=as.factor(Hour)]
  
  
  return(raw_data)
  
}

feature_filter<-function(processed_data){
  set.seed(1)
  fit1=ranger(Consumption~ ., data = processed_data, num.trees = 500, 
             importance = "impurity_corrected", always.split.variables=c("Hour"),replace=TRUE,
             splitrule="extratrees", keep.inbag=TRUE,num.random.splits=5,num.threads=4)
  importances1<-fit1$variable.importance
  barplot(sort(importances1,decreasing = TRUE),las=2)
  importances1<-names(importances1[(importances1>0)])
  return(importances1)
}

best_ranger<-function(processed_data,prediction_date,num_of_days_in_adv,method,today){
  
  temp_processed_data<-processed_data[Date<=prediction_date]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,TWeekDay:=wday(Date)]
  train[,TWeekDay:=as.character(TWeekDay)]
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date==prediction_date])
  result=as.data.table(test)
  train<-train[Date<=prediction_date-num_of_days_in_adv]
  ranger_test=as.data.table(test[,Consumption:=NA])
  
  trainx=train[,-c('Date'),with=F]
  train=train[complete.cases(train)]
  trainx=trainx[complete.cases(trainx)]
  ids=c(grep('Hour',names(train)))
  
  
  
  
  tgrid <- expand.grid(.mtry = c(floor(sqrt(ncol(train))),floor(ncol(train)/3)),
                       .splitrule = c("extratrees"),
                       .min.node.size = c(10,20,30))
  
  set.seed(1)
  my_partitions<-createTimeSlices(1:nrow(trainx),initialWindow = 180*24, horizon = 24*(num_of_days_in_adv),skip=(180*24-1),fixedWindow = T)
  ctrl <- trainControl(method=method,index = my_partitions$train, indexOut = my_partitions$test)
  trainx[,Hour:=as.numeric(Hour)]
  model_caret <- train(Consumption~ ., data = trainx,
                       method = "ranger",
                       trControl = ctrl,
                       tuneGrid = tgrid,
                       importance = c('impurity'),always.split.variables=c("Hour")
                       ,num.random.splits=5,num.threads=4,max.depth=14,replace=TRUE, num.trees = 500)
  return(model_caret$bestTune)
}

best_rfma<-function(processed_data,prediction_date,num_of_days_in_adv,method,today){
  
  temp_processed_data<-processed_data[Date<=prediction_date]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date==prediction_date])
  result=as.data.table(test)
  train<-train[Date<=prediction_date-num_of_days_in_adv]
  ranger_test=as.data.table(test[,Consumption:=NA])
  train=train[complete.cases(train)]
  #trainx=train[,-c('Date'),with=F]
  
  
  
  
  tgrid <- expand.grid(.mtry = 7,
                       .splitrule = c("extratrees"),
                       .min.node.size = 10,
                       num_of_split=c(1),
                       with_replacement=c(TRUE),
                       always_split=list(c("Hour")))
  
  set.seed(1)
  my_partitions<-createTimeSlices(1:nrow(train),initialWindow = 180*24, horizon = 24*(num_of_days_in_adv),skip=(180*24-1),fixedWindow = T)
  ctrl <- trainControl(method=method,index = my_partitions$train, indexOut = my_partitions$test)
  
  rfma_cross_val<-data.table()

  
  for (i in 1: nrow(tgrid)){
    parameters<-tgrid[i,]
    for(k in 1:length(my_partitions$train)){
      train_ind<-unlist(my_partitions$train[k], use.names=FALSE)
      test_ind<-unlist(my_partitions$test[k], use.names=FALSE)
      train_cv<-train[train_ind,]
      train_cv_wo_date<-train_cv[,-c('Date'),with=F]
      test_cv<-train[test_ind,]
      test_cv_wo_date<-test_cv[,-c('Date'),with=F]
      test_cv_wo_date_response<-test_cv_wo_date[,Consumption:=NA]
      
      
      
      fit=ranger(Consumption~ ., data = train_cv_wo_date, num.trees = 500, mtry=parameters$.mtry, 
                 importance = "impurity",min.node.size=parameters$.min.node.size, always.split.variables=c("Hour"),replace=parameters$with_replacement,
                 splitrule=parameters$.splitrule, keep.inbag=TRUE,num.random.splits=parameters$num_of_split,num.threads=4)
      
      predicted_terminals=predict(fit,train_cv_wo_date,predict.all=TRUE,type='terminalNodes')$predictions
      inbag = data.table(do.call(cbind, fit$inbag.counts))
      inbag[inbag==0]=NA
      inbag[!is.na(inbag)]=1
      predicted_oob=predicted_terminals*as.matrix(inbag)
      baseline_train=data.table(train_cv[,list(Date,Hour,Consumption)],predicted_oob)
      
      
      predicted_terminals_test=predict(fit,test_cv_wo_date_response,predict.all=TRUE,type='terminalNodes')$predictions
      baseline_test=data.table(test_cv[,list(Date,Hour,Consumption)],predicted_terminals_test)
      
      baseline_whole=rbind(baseline_train,baseline_test)
      baseline_whole=baseline_whole[order(Date,Hour)]
      basenames=names(baseline_whole)
      baseline=melt(baseline_whole,id.vars=c('Date','Hour','Consumption'),measure_vars=basenames[!(basenames %in% c('Date','Hour','Consumption'))])
      baseline=baseline[!is.na(value)]
      
      setDT(baseline)[, id := .GRP, by=list(Hour,variable,value)]      
    
      #weighted moving average according to day difference
      baseline[, j :=as.numeric( Date-shift(Date, fill = NA,n=1)), by = id]
      baseline[, yj := shift(Consumption, fill = NA,n=1), by = id]
      #baseline[, k :=as.numeric( Date - shift(Date, fill = NA,n=2)), by = id]
      #baseline[, yk := shift(Consumption, fill = NA,n=2), by = id]
      #baseline[,lag_same_node:=ifelse( k<=30 & (!is.na(k))&(j<=30)&(!is.na(yj)),k*yj/(k+j)+j*yk/(k+j),
      #                                 ifelse((k>30|is.na(k)) & (j<=30)&(!is.na(yj)),yj,
      #                                        ifelse((j>30)&(!is.na(yj)),yj,NA)))]
      baseline[,lag_same_node:=ifelse( j<=30, yj,NA)]

      
      
      baseline_test_temp<-baseline[(baseline$Date %in% test_cv$Date)]
      baseline_test_temp[,lag_same_node:=na.locf(lag_same_node, na.rm = FALSE),by=id]
      
      temp=baseline_test_temp[,list(Similar_Consumption=median(lag_same_node,na.rm=T)),by=list(Date,Hour)]
      temp=temp[order(Date,Hour)]
      
      result<-data.table(join(test_cv, temp, by = c("Date","Hour"), type = "left", match = "all"))
      
      columns<-c("Date","Hour","Consumption","Similar_Consumption")
      result<-result[,colnames(result) %in% columns, with=FALSE]
      rfma_cross_val<-rbind(rfma_cross_val,data.table(mtry=parameters$.mtry,
                                                      splitrule=parameters$.splitrule,
                                                      min_node_size=parameters$.min.node.size,
                                                      number_of_split=as.factor(parameters$num_of_split),
                                                      always_split_variables=as.factor(parameters$always_split),
                                                      with_replacement=as.factor(parameters$with_replacement),
                                                      dataset_id=k,
                                                      mape=MAPE(y_true = result$Consumption,y_pred = result$Similar_Consumption)))
      
        }
  print(i)
  }
  
        
  cross_val<-rfma_cross_val[,mean(mape),by=list(mtry,min_node_size,number_of_split,always_split_variables,with_replacement)]

  return(cross_val)
}

best_models<-function(processed_data,prediction_date,num_of_days_in_adv,method,today){
  
  temp_processed_data<-processed_data[Date<=prediction_date]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,TWeekDay:=wday(Date)]
  train[,TWeekDay:=as.character(TWeekDay)]
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date==prediction_date])
  result=as.data.table(test)
  train<-train[Date<=prediction_date-num_of_days_in_adv]

  
  trainx=train[,-c('Date'),with=F]
  train=train[complete.cases(train)]
  trainx=trainx[complete.cases(trainx)]
  
  cols <-  colnames(train)[sapply(train, class) == 'logical']
  train[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  cols <-  colnames(train)[sapply(train, class) == 'character']
  train[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  
  my_partitions<-createTimeSlices(1:nrow(trainx),initialWindow = 180*24, horizon = 24*(num_of_days_in_adv),skip=(180*24-1),fixedWindow = T)
  ctrl <- trainControl(method="timeslice",index = my_partitions$train, indexOut = my_partitions$test)
  
  
  #GBM
  set.seed(1)
  model_gbm<- train(Consumption~.-Date, data = train,     method = "gbm" , trControl = ctrl, metric="RMSE")
  cat("GBM is Done")
  #SVM

  #set.seed(1)
  #model_svm<- train(Consumption~.-Date, data = train,     method = "svmPoly",trControl = ctrl,  metric="RMSE")
  #cat("SVM is Done")
  
  #GLM
  set.seed(1)
  model_glmnet<- train(Consumption~.-Date, data = train,     method = "glmnet",trControl = ctrl,  metric="RMSE")
  cat("GLM is Done")
  
  #DT
  set.seed(1)
  model_dt<- train(Consumption~.-Date, data = train,     method = "rpart",trControl = ctrl,   metric="RMSE")
  cat("DT is Done")
  
  
  #KNN
  set.seed(1)
  model_knn<- train(Consumption~.-Date, data = train,     method = "knn",trControl = ctrl,  metric="RMSE")
  cat("KNN is Done")
  
  #XGB
  set.seed(1)
  model_xgbtree<- train(Consumption~.-Date, data = train,     method = "xgbTree",trControl = ctrl, metric="RMSE")
  cat("XGB is Done")
  
  
  
  return(c(model_gbm$bestTune,model_glmnet$bestTune ,model_dt$bestTune,model_knn$bestTune,model_xgbtree$bestTune))
}

forecast_rfma_without_arima<-function(processed_data,today,num_of_days_in_adv,mtry,min_node_size,splitrule){
  
  temp_processed_data<-processed_data[Date<=today+num_of_days_in_adv]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,TWeekDay:=wday(Date)]
  train[,TWeekDay:=as.character(TWeekDay)]
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date>today & Date<=today+num_of_days_in_adv])
  result=as.data.table(test)
  ranger_train<-train[Date<=today]
  ranger_test=as.data.table(test[,Consumption:=NA])
  
  ranger_trainx=ranger_train[,-c('Date'),with=F]
  ranger_train=ranger_train[complete.cases(ranger_train)]
  ranger_trainx=ranger_trainx[complete.cases(ranger_trainx)]
  ids=c(grep('Hour',names(ranger_train)))
  
  
  
  fit=ranger(Consumption~ ., data = ranger_trainx, num.trees = 500, mtry=mtry, 
             importance = "impurity",min.node.size=min_node_size, always.split.variables=c(names(ranger_train)[ids],"ramazanbayrami","kurbanbayrami"),replace=TRUE,
             splitrule=splitrule, keep.inbag=TRUE,num.random.splits=5,num.threads=4,max.depth=14)
  
  
  prediction_data=rbind(ranger_train[complete.cases(ranger_train)])
  predicted_terminals=predict(fit,prediction_data,predict.all=TRUE,type='terminalNodes')$predictions
  inbag = data.table(do.call(cbind, fit$inbag.counts))
  inbag[inbag==0]=NA
  inbag[!is.na(inbag)]=1
  predicted_oob=predicted_terminals*as.matrix(inbag)
  baseline_train=data.table(ranger_train[,list(Date,Hour,Consumption)],predicted_oob)
  
  predicted_terminals_test=predict(fit,ranger_test,predict.all=TRUE,type='terminalNodes')$predictions
  baseline_test=data.table(ranger_test[,list(Date,Hour,Consumption)],predicted_terminals_test)
  
  baseline_whole=rbind(baseline_train,baseline_test)
  baseline_whole=baseline_whole[order(Date,Hour)]
  basenames=names(baseline_whole)
  baseline=melt(baseline_whole,id.vars=c('Date','Hour','Consumption'),measure_vars=basenames[!(basenames %in% c('Date','Hour','Consumption'))])
  baseline=baseline[!is.na(value)]
  
  setDT(baseline)[, id := .GRP, by=list(Hour,variable,value)]
  
  #weighted moving average according to day difference
  #baseline[, j :=as.numeric( Date-shift(Date, fill = NA,n=1)), by = id]
  baseline[, yj := shift(Consumption, fill = NA,n=1), by = id]
  #baseline[, k :=as.numeric( Date - shift(Date, fill = NA,n=2)), by = id]
  baseline[, yk := shift(Consumption, fill = NA,n=2), by = id]
  #baseline[,lag_same_node:=ifelse( k<=30 & (!is.na(k))&(j<=30)&(!is.na(yj)),k*yj/(k+j)+j*yk/(k+j),
  #                                 ifelse((k>30|is.na(k)) & (j<=30)&(!is.na(yj)),yj,
  #                                        ifelse((j>30)&(!is.na(yj)),yj,NA)))]
  baseline[,lag_same_node1:=yj]
  baseline[,lag_same_node2:=(yj+yk)/2]                                 
                                   
  
  baseline_test_temp<-baseline[((Date>today)  & (Date<=today+num_of_days_in_adv))]
  baseline_test_temp[,lag_same_node1:=na.locf(lag_same_node1, na.rm = FALSE),by=id]
  baseline_test_temp[,lag_same_node2:=na.locf(lag_same_node2, na.rm = FALSE),by=id]
  
  #baseline[,lag_same_node:=roll_meanr(c(Consumption),3,fill = NA,na.rm = T,weights = c(0.5,0.5,0)),by=list(Hour,variable,value)]
  temp=baseline_test_temp[,list(Similar_Consumption1=median(lag_same_node1,na.rm=T)),by=list(Date,Hour)]
  temp2=baseline_test_temp[,list(Similar_Consumption2=median(lag_same_node2,na.rm=T)),by=list(Date,Hour)]
  temp<-merge(temp, y = temp2, by = c("Date","Hour"), all.x=TRUE)
  temp=temp[order(Date,Hour)]
  
  #NA interpolation 
  #commnd=sprintf('temp[,%s:=as.numeric(na.interp(ts(%s)))]',"Similar_Consumption","Similar_Consumption")
  #eval(parse(text=commnd))
  
  
  #Random Forest----
  ranger_testx<-ranger_test[,-c('Date'),with=F]
  forecast_rf<-data.table(predict(fit,ranger_testx,predict.all=FALSE,type="response")$predictions)
  #end----    
  
  #test----
  
  result<-data.table(join(result, temp, by = c("Date","Hour"), type = "left", match = "all"))
  result[,Random_Forest:=forecast_rf]
  result[,Today:=today]
  #end----
  
  colnames(result)[3] <- "Actual Consumption"
  columns<-c("Date","Hour","Today","Actual Consumption","Similar_Consumption1","Similar_Consumption2","Random_Forest")
  result<-result[,colnames(result) %in% columns, with=FALSE]
  return(result)
  
}    


tbma_feature<-function(processed_data,today,num_of_days_in_adv){
  
  temp_processed_data<-processed_data[Date<=today+num_of_days_in_adv]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,TWeekDay:=wday(Date)]
  train[,TWeekDay:=as.character(TWeekDay)]
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date>today & Date<=today+num_of_days_in_adv])
  ranger_train<-train[Date<=today]
  ranger_test=as.data.table(test[,Consumption:=NA])
  
  ranger_trainx=ranger_train[,-c('Date'),with=F]
  ranger_train=ranger_train[complete.cases(ranger_train)]
  ranger_trainx=ranger_trainx[complete.cases(ranger_trainx)]
  ids=c(grep('Hour',names(ranger_train)))
  
  
  result<-data.table()
  tgrid <- expand.grid(.mtry = c(floor(sqrt(ncol(train))),floor(sqrt(ncol(train))*2)),
                       .splitrule = c("extratrees"),
                       .min.node.size = c(10,50),
                       always_split=list(c(names(ranger_train)[ids],"ramazanbayrami","kurbanbayrami"),c()))
  
  for (i in 1:nrow(tgrid)) {
  
    parameters<-tgrid[i,]
  
    if(!is.null(parameters$always_split[[1]])){
      fit=ranger(Consumption~ ., data = ranger_trainx, num.trees = 100, mtry=parameters$.mtry, 
                 importance = "impurity",min.node.size=parameters$.min.node.size, always.split.variables=parameters$always_split[[1]],replace=TRUE,
                 splitrule=splitrule, keep.inbag=TRUE,num.random.splits=5,num.threads=4,max.depth=14)}
    if(is.null(parameters$always_split[[1]])){
      fit=ranger(Consumption~ ., data = ranger_trainx, num.trees = 100, mtry=parameters$.mtry, 
                 importance = "impurity",min.node.size=parameters$.min.node.size,replace=TRUE,
                 splitrule=splitrule, keep.inbag=TRUE,num.random.splits=5,num.threads=4,max.depth=14)}
  
  
  prediction_data=ranger_train[complete.cases(ranger_train)]
  predicted_terminals=predict(fit,prediction_data,predict.all=TRUE,type='terminalNodes')$predictions
  inbag = data.table(do.call(cbind, fit$inbag.counts))
  inbag[inbag==0]=NA
  inbag[!is.na(inbag)]=1
  predicted_oob=predicted_terminals*as.matrix(inbag)
  baseline_train=data.table(ranger_train[,list(Date,Hour,Consumption)],predicted_oob)
  
  predicted_terminals_test=predict(fit,ranger_test,predict.all=TRUE,type='terminalNodes')$predictions
  baseline_test=data.table(ranger_test[,list(Date,Hour,Consumption)],predicted_terminals_test)
  
  baseline_whole=rbind(baseline_train,baseline_test)
  baseline_whole=baseline_whole[order(Date,Hour)]
  basenames=names(baseline_whole)
  baseline=melt(baseline_whole,id.vars=c('Date','Hour','Consumption'),measure_vars=basenames[!(basenames %in% c('Date','Hour','Consumption'))])
  baseline=baseline[!is.na(value)]
  
  
  setDT(baseline)[, id1 := .GRP, by=list(Hour,variable,value)]
  setDT(baseline)[, id2 := .GRP, by=list(Hour,variable,value)]
  
  #weighted moving average according to day difference
  #baseline[, j :=as.numeric( Date-shift(Date, fill = NA,n=1)), by = id]
  baseline[, yj := shift(Consumption, fill = NA,n=1), by = id1]
  #baseline[, k :=as.numeric( Date - shift(Date, fill = NA,n=2)), by = id]
  baseline[, yk := shift(Consumption, fill = NA,n=2), by = id1]
  #baseline[,lag_same_node:=ifelse( k<=30 & (!is.na(k))&(j<=30)&(!is.na(yj)),k*yj/(k+j)+j*yk/(k+j),
  #                                 ifelse((k>30|is.na(k)) & (j<=30)&(!is.na(yj)),yj,
  #                                        ifelse((j>30)&(!is.na(yj)),yj,NA)))]
  baseline[,lag_same_node1_id1:=yj]
  baseline[,lag_same_node2_id1:=(yj+yk)/2]                                 
  
  #weighted moving average according to day difference
  #baseline[, j :=as.numeric( Date-shift(Date, fill = NA,n=1)), by = id]
  baseline[, yj := shift(Consumption, fill = NA,n=1), by = id2]
  #baseline[, k :=as.numeric( Date - shift(Date, fill = NA,n=2)), by = id]
  baseline[, yk := shift(Consumption, fill = NA,n=2), by = id2]
  #baseline[,lag_same_node:=ifelse( k<=30 & (!is.na(k))&(j<=30)&(!is.na(yj)),k*yj/(k+j)+j*yk/(k+j),
  #                                 ifelse((k>30|is.na(k)) & (j<=30)&(!is.na(yj)),yj,
  #                                        ifelse((j>30)&(!is.na(yj)),yj,NA)))]
  
  baseline[,lag_same_node1_id2:=yj]
  baseline[,lag_same_node2_id2:=(yj+yk)/2]   

  baseline[,lag_same_node1_id1:=na.locf(lag_same_node1_id1, na.rm = FALSE),by=id1]
  baseline[,lag_same_node2_id1:=na.locf(lag_same_node2_id1, na.rm = FALSE),by=id1]
  baseline[,lag_same_node1_id2:=na.locf(lag_same_node1_id2, na.rm = FALSE),by=id2]
  baseline[,lag_same_node2_id2:=na.locf(lag_same_node2_id2, na.rm = FALSE),by=id2]
  
  #baseline[,lag_same_node:=roll_meanr(c(Consumption),3,fill = NA,na.rm = T,weights = c(0.5,0.5,0)),by=list(Hour,variable,value)]
  temp=baseline[,list(Similar_Consumption1_id1=median(lag_same_node1_id1,na.rm=T)),by=list(Date,Hour)]
  temp2=baseline[,list(Similar_Consumption2_id1=median(lag_same_node2_id1,na.rm=T)),by=list(Date,Hour)]
  temp3=baseline[,list(Similar_Consumption1_id2=median(lag_same_node1_id2,na.rm=T)),by=list(Date,Hour)]
  temp4=baseline[,list(Similar_Consumption2_id2=median(lag_same_node2_id2,na.rm=T)),by=list(Date,Hour)]
  temp<-merge(temp, y = temp2, by = c("Date","Hour"), all.x=TRUE)
  temp<-merge(temp, y = temp3, by = c("Date","Hour"), all.x=TRUE)
  temp<-merge(temp, y = temp4, by = c("Date","Hour"), all.x=TRUE)
  temp=temp[order(Date,Hour)]
  
  names(temp)[names(temp) == "Similar_Consumption1_id1"] <- paste0('TBMA Order:1 Grid:',i,"ID:1")
  names(temp)[names(temp) == "Similar_Consumption2_id1"] <- paste0('TBMA Order:2 Grid:',i,"ID:1")
  names(temp)[names(temp) == "Similar_Consumption1_id2"] <- paste0('TBMA Order:1 Grid:',i,"ID:2")
  names(temp)[names(temp) == "Similar_Consumption2_id2"] <- paste0('TBMA Order:2 Grid:',i,"ID:2")
  #end----
  
  if(i==1){
  result<-cbind(result,temp)}
  
  if(i>1){
    result<-merge(result, y = temp, by = c("Date","Hour"), all.x=TRUE)
  }
  
  }
  
  return(result)
  
}    






predict_arima<-function(processed_data,today,num_of_days_in_adv){
  
  temp_processed_data<-processed_data[Date<=today+num_of_days_in_adv]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date>today & Date<=today+num_of_days_in_adv])
  result=as.data.table(test)
  train<-train[Date<=today]
  test=as.data.table(test[,Consumption:=NA])
  
  trainx=train[,-c('Date'),with=F]
  trainx=train[complete.cases(train)]
  trainx=trainx[complete.cases(trainx)]
  
  
  #Arima----
  forecast_arima<-data.table()
  for(k in 0:23){
    consumption_ts<-ts(train[Hour==k]$Consumption,frequency=7,start = c(1))
    fit_arima<-auto.arima(consumption_ts)
    for(l in 1:num_of_days_in_adv){
      forecast_arima<-rbind(forecast_arima,data.table(Hour=k,Date=today+l,Today=today,Arima = data.table(forecast(fit_arima,h=num_of_days_in_adv)$mean[l])))
    }
  }
  #end----
  
  
  
  colnames(forecast_arima)[colnames(forecast_arima)=="Arima.V1"] <- "Arima"
  colnames(result)[3] <- "Actual Consumption"
  columns<-c("Date","Hour","Actual Consumption","Arima","Today")
  result<-join(result,forecast_arima,by=c("Date","Hour"))
  result<-result[,colnames(result) %in% columns, with=FALSE]
  return(result)
  
}





add_models<-function(processed_data,today,num_of_days_in_adv,interaction.depth,n.trees,shrinkage,n.minobsinnode,cost,scale,degree, alpha,lambda,cp,k,
                     nrounds, max_depth, eta, gamma, colsample_bytree, min_child_weight, subsample){

  temp_processed_data<-processed_data[Date<=today+num_of_days_in_adv]
  
  verbose=TRUE
  train=copy(temp_processed_data)
  train[,LagConsumption7:=ifelse(Date-today>7,NA,shift(Consumption,168))]
  
  
  test=as.data.table(train[Date>today & Date<=today+num_of_days_in_adv])
  result=as.data.table(test)
  train<-train[Date<=today]
  test=as.data.table(test[,Consumption:=NA])

  testx=test[,-c('Date'),with=F]
  trainx=train[,-c('Date'),with=F]
  train=train[complete.cases(train)]
  trainx=trainx[complete.cases(trainx)]
  
  
  cols <-  colnames(train)[sapply(train, class) == 'logical']
  train[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  cols <-  colnames(train)[sapply(train, class) == 'character']
  train[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  cols <-  colnames(test)[sapply(test, class) == 'logical']
  test[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  cols <-  colnames(test)[sapply(test, class) == 'character']
  test[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  cols <-  colnames(trainx)[sapply(trainx, class) == 'logical']
  trainx[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]
  cols <-  colnames(trainx)[sapply(trainx, class) == 'character']
  trainx[, (cols) := lapply(.SD, function(x) as.factor(factor(x))), .SDcols = cols]

  
  
  ##GBM
  gbm_fit=gbm(Consumption~.-Date ,data = train,distribution = "gaussian",n.trees = n.trees,  shrinkage = shrinkage, interaction.depth = interaction.depth)
  result_gbm<-data.table(test,GBM=predict(gbm_fit,test,n.trees = n.trees))


  ##SVR
  control <- trainControl(method = "none" )
  #tgrid <- expand.grid(degree=degree,scale=scale,C=C)
  #model_svm <- train(Consumption ~.-Date, data=train, trControl = control, method = "svmPoly",tuneGrid =tgrid)
  #result_svm<-data.table(test,SVM=predict(model_svm, test))
  
  ##GLM
  tgrid <- expand.grid(alpha=alpha,lambda=lambda)
  model_glmnet <- train(Consumption ~.-Date, data=train, trControl = control, method = "glmnet",tuneGrid =tgrid)
  result_glm<-data.table(test,GLMNET=predict(model_glmnet, test))
  
  ##Decision Tree
  tgrid <- expand.grid(cp=cp)
  model_dt <- train(Consumption ~.-Date, data=train, trControl = control, method = "rpart",tuneGrid =tgrid)
  result_dt<-data.table(test,DT=predict(model_dt, test))
  
  #knn
  tgrid <- expand.grid(k=k)
  model_knn <- train(Consumption ~.-Date, train, trControl = control, method = "knn",tuneGrid =tgrid)
  result_knn<-data.table(test,KNN=predict(model_knn, test))
  
  #XGB
  tgrid <- expand.grid(nrounds=nrounds, max_depth=max_depth, eta=eta, gamma=gamma, colsample_bytree=colsample_bytree
                       , min_child_weight=min_child_weight, subsample=subsample)
  model_xgb <- train(Consumption ~.-Date, train, trControl = control, method = "xgbTree",tuneGrid =tgrid)
  result_xgb<-data.table(test,XGB=predict(model_xgb, test))  

  
  
  result<-merge(result, y = result_gbm[ , c("Date", "Hour","GBM")], by = c("Date","Hour"), all.x=TRUE)
  #result<-merge(result, y = result_svm[ , c("Date", "Hour","SVM")], by = c("Date","Hour"), all.x=TRUE)
  result<-merge(result, y = result_glm[ , c("Date", "Hour","GLMNET")], by = c("Date","Hour"), all.x=TRUE)
  result<-merge(result, y = result_dt[ , c("Date", "Hour","DT")], by = c("Date","Hour"), all.x=TRUE)
  result<-merge(result, y = result_knn[ , c("Date", "Hour","KNN")], by = c("Date","Hour"), all.x=TRUE)
  result<-merge(result, y = result_xgb[ , c("Date", "Hour","XGB")], by = c("Date","Hour"), all.x=TRUE)
  result[,Today:=today]
  columns<-c("Date","Hour","Today","Consumption","GBM","SVM","GLMNET","DT","KNN","XGB")
  result<-result[,colnames(result) %in% columns, with=FALSE]
  return(result)
  
}


