library(data.table)
library(ranger)
library(RcppRoll)
library(lubridate)
library(readr)
library(plyr)
library(forecast)
library(weathermetrics)
library(forecast)
library(caret)
library(zoo)

free <- function() invisible(gc())
  
    number_of_replication<-1
    prediction_date<-as.Date("2018-01-01")                 #first date to predict                      
    num_of_days_to_predict<-372                          #how many days we want to predict
    directory_of_raw_data<-""
    source_date_based_info<-""
    source_weather<-""
    directory_weather_file<-""       #only the file
    source_functions<-""
    num_of_days_in_adv<-7
    set.seed(1)
    
    
    source(source_functions)
    #data preparation
    processed_data<-data_preperation(directory_of_raw_data,source_date_based_info,source_weather,directory_weather_file)
    rm(list=setdiff(ls(), c("processed_data","prediction_date","num_of_days_in_adv","num_of_days_to_predict","number_of_replication",
                            "best_models","add_models","forecast_rfma_without_arima","ozel_gun_adları","ozel_gunler","free","feature_filter","best_ranger")))
    
    free()
    
    #feature selection
    selected_columns<-feature_filter(processed_data = processed_data)
    processed_data<-processed_data[,colnames(processed_data) %in% c(selected_columns,"Consumption","Date","Hour"), with=FALSE]
   
    #cv for models
    final_model<-best_ranger(processed_data =processed_data,prediction_date,num_of_days_in_adv = num_of_days_in_adv,method="timeslice",today=prediction_date-num_of_days_in_adv)
    final_models<-best_models(processed_data =processed_data,prediction_date,num_of_days_in_adv = num_of_days_in_adv,method="timeslice",today=prediction_date-num_of_days_in_adv)

    
    
    
    forecast<-data.table()
    for(z in 1:num_of_days_to_predict){
    
      tm=Sys.time()  
            tm=Sys.time()
            set.seed(1)
            tbma<-forecast_rfma_without_arima(processed_data = processed_data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv = num_of_days_in_adv,
                                              mtry =final_model$mtry,min_node_size = final_model$min_node_size,splitrule =final_model$splitrule)
            other_models<-add_models(processed_data=processed_data,today=prediction_date-num_of_days_in_adv+z-1,num_of_days_in_adv=num_of_days_in_adv,
                                     interaction.depth=final_models$interaction.depth,n.trees=final_models$n.trees,shrinkage=final_models$shrinkage,
                                     n.minobsinnode=final_models$n.minobsinnode,alpha=final_models$alpha,lambda=final_models$lambda,
                                     cp=final_models$cp,k=final_models$k,nrounds=final_models$nrounds, max_depth=final_models$max_depth, eta=final_models$eta,
                                     gamma=final_models$gamma, colsample_bytree=final_models$colsample_bytree, min_child_weight=final_models$min_child_weight,
                                     subsample=final_models$subsample)
            combined<-result<-merge(tbma, other_models, by = c("Date","Hour"), all.x=TRUE)
            forecast<-rbind(forecast,data.table(Today=prediction_date-num_of_days_in_adv+z-1,combined))
            cat("\n", z,"\n compute time:",(Sys.time()-tm),"   prediction date:",as.Date(prediction_date+z-1),"  num_of_days_in_adv:",num_of_days_in_adv ,"\n")
      free()  
    
    }
    
    

    write.csv(forecast,file="add_models2.csv")
    write.csv(final_model,file="model_parameters.csv")
    write.csv(selected_columns,file="selected_columns.csv")
    write.csv(final_models,file="model_parameters2.csv")
    
    
    